from .models import TutorReg
from rest_framework import viewsets
from rest_framework import permissions
from tutorapp.serializers import TutorSerializer
class TutorViewSet(viewsets.ModelViewSet):
    queryset = TutorReg.objects.all()
    serializer_class = TutorSerializer

